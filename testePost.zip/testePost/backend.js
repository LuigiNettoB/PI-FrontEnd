const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const port = 3000;

// Middleware para permitir CORS
app.use(cors());
app.use(express.json());

// Conexão com o MongoDB
mongoose.connect('mongodb+srv://pedronoelialamov:YCONLNiEQOOA5a64@cluster0.imjcz.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('Conectado ao MongoDB'))
.catch(err => console.log('Erro ao conectar ao MongoDB:', err));

// Definição do esquema de Postagem (Post)
const PostSchema = new mongoose.Schema({
    user: String,
    text: String,
    date: { type: Date, default: Date.now }
});

const Post = mongoose.model('Post', PostSchema);

// Rota para criar uma nova postagem
app.post('/posts', async (req, res) => {
    try {
        const { user, text } = req.body;
        const newPost = new Post({ user, text });
        await newPost.save();
        res.status(201).json(newPost);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Rota para obter todas as postagens
app.get('/posts', async (req, res) => {
    try {
        const posts = await Post.find().sort({ date: -1 });  // Ordena por data, da mais recente para a mais antiga
        res.json(posts);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
